#include <iostream>
#include <string>
#include <fstream>
#include <bitset>
#include <math.h>       
using namespace std;


#define ADDRESSBUS_BITS 32
#define DATABUS_BITS 8
#define TAG_BITS 16
#define SET_BITS 14.0
#define WORD_BITS 2


#define TagHex 0xFFFF0000;
#define WordHex 0x00000003;
#define SetHex 0x0000FFFC;

#define FULL_Assoctiv_TagHex 0xFFFFFFFC; //11111111111111111111111111111100





//cache line as a struct 
struct cachesEntry
{
	bool LRU;
	bool invaild;
	unsigned int Tag;// was unsigned short (16-bits) changed to unsigned int, to allow 30 bits  for fully associative 
	char bytes[4];
};


const int index_size = 16384;//2^14  =  16K    

struct cachesEntry directmap[index_size];
struct cachesEntry TwoWayCacheing[2][index_size];
struct cachesEntry FullyAssociativeMap[index_size];



void DirectMap(unsigned int CPUaddress);            //direct map function, inputs: 32bit cpu address, outputs: none 
void Twowayset(unsigned int CPUaddress);  //2-way set associative function, inputs: 32bit cpu address, outputs: none 
void SetAssociate(unsigned int CPUaddress);          //direct map function, inputs: 32bit cpu address, outputs: none 

//function to select one of three cache methods 
int user_cache_pick(int a);// inputs:  1 - 3 for each cache option 

void initilise_all_cache();// initilise the 3 cache to zero/invalid. 


int HIT = 0;
int MISS = 0;
unsigned int CPUaddr;


fstream my_file;
string fileName;

int main()
{
	int ans;//to pick one of the cache designs

	initilise_all_cache(); //to zero 

	fileName = "input_addr_setassocitive_7M_2H.txt";
	std::cout << "\nFile used will be :" << fileName<< std::endl;

	std::cout << "\n|----------------Which cacheing method would you like to go with ?-----------------|" << std::endl;
	std::cout << "\n|-----(1)--DirectMapping--(2)--2-way-set-associative--(3)--full-set-associative----|" << std::endl;
	std::cout << "\nYour input ==> ";
	std::cin >> ans;


	if (user_cache_pick(ans)) {

		std::cout << "\n---------------------------------------------" << std::endl;
		std::cout << "Total number of hits => " << std::dec << HIT << std::endl;
		std::cout << "Total number of misses => " << std::dec << MISS << std::endl;
		std::cout << "---------------------------------------------" << std::endl;

	}

}

void DirectMap(unsigned int CPUaddress)
{

	std::cout << "\n+++++++++++++++++++++++++++++++++++++Address has been read in :: " << hex << CPUaddress << std::endl;

	//isolating the tag, set, wrd field by preforming a  bitwise AND '&' operation
	unsigned int BytesN = CPUaddress & WordHex; //bitwise AND the WordHex with cpu address, save to BytesN with size 32 bits  
	unsigned int SetN = CPUaddress & SetHex;    //bitwise AND the SetHex  with cpu address, save to SetN  with size 32 bits
	unsigned int Tag = CPUaddress & TagHex;     //bitwise AND the TagHex  with cpu address, save to Tag   with size 32 bits

	//right shift the tag and SetN
	Tag = Tag >> 16;  //eg,   11101111011101010000000000000000 >> 16 
	                //tag =>  00000000000000001110111101110101
	SetN = SetN >> 2;

	std::cout << "\nThe resulting address in the form:"<< std::endl;
	std::cout << "BytesN => " << hex<<BytesN << std::endl; //testing
	std::cout << "TAG => "    << hex<<Tag    << std::endl; //testing
	std::cout << "SetN   => " << hex<<SetN   << std::endl;   //testing

	std::cout << "\n=================================================HIT=========MISS======= " << std::endl;


	//using the setN value to access the relevent cache line 
	//checking if the tag matched and its not invalid 
	if ((directmap[SetN].Tag == Tag) && (!directmap[SetN].invaild))
	{
		std::cout << "\nAddress is                                      a Hit  " << std::endl;
		HIT++;
	}
	else
	{
		//if address is invalid, its a miss, save the tag and flip the invalid.   
		std::cout << "\nAddress is                                                   a Miss  " << std::endl;
		directmap[SetN].Tag = Tag;
		directmap[SetN].invaild = false;
		MISS++;
	}
	
	std::cout << "\n======================================================================== " << std::endl;
	std::cout << "The line number of the data loaded from memory is    " << SetN << std::endl;
	std::cout << "\nStatus of hits and Miss:"<< std::endl;
	std::cout << "Amount of hits   => " << std::dec << HIT << std::endl;
	std::cout << "Amount of misses => " << std::dec << MISS << std::endl;
}




void Twowayset(unsigned int CPUaddress)
{
	    int way = 2;  //2-way, declared for future modification for N-way set associative  

		int flagHM = 0;//a hit miss flag, 0 = miss, 1 = hit 

		std::cout << "\n+++++++++++++++++++++++++++++++++++++Address has been read in :: " << hex << CPUaddress << std::endl;

		//isolating the tag, set, wrd field by preforming a  bitwise AND '&' operation
		unsigned int BytesN = CPUaddress & WordHex;  //bitwise AND the WordHex with cpu address, save to BytesN with size 32 bits
		unsigned int SetN = CPUaddress & SetHex;    //bitwise AND the SetHex  with cpu address, save to SetN  with size 32 bits
		unsigned int Tag = CPUaddress & TagHex;    //bitwise AND the TagHex  with cpu address, save to Tag   with size 32 bits

		//right shift the tag and SetN
		Tag = Tag >> 16; 
		SetN = SetN >> 2; 

		std::cout << "\nThe resulting address in the form:" << std::endl;
		std::cout << "BytesN => " << BytesN << std::endl; 
		std::cout << "TAG    => " << Tag    << std::endl; 
		std::cout << "SetN   => " << SetN   << std::endl;   

		std::cout << "\n=================================================HIT=========MISS======= " << std::endl;


		//using 'for' loop to access way 0 and way 1 (these are the 2-way)
		//during the for loop using setN to access cacheline and check if tag and lru conditions met 
		for (int x = 0; x < way; x++) {

			if ((TwoWayCacheing[x][SetN].Tag == Tag) && (TwoWayCacheing[x][SetN].LRU == false )) {

				//if conditions met, its a hit, set the flagHM = 1 (means hit ) and break from loop 
				std::cout << "\nAddress is                                      a Hit  " << std::endl;
				flagHM = 1;
				break;
			}
			else {
				flagHM = 0;
			}
		}

		//check flagHM value, if its 1 means hit, then increment hit counter
		if (flagHM == 1) {

			HIT++;
		}
		else {
			// else means its 0 ie a miss, then increment miss counter
			MISS++;
			std::cout << "\nAddress is                                                   a Miss  " << std::endl;

			//using 'for' go into way 0 & 1 and find the least reciantly used (LRU) cache line and save the address there
			for (int x = 0; x < way; x++) { 

				if (TwoWayCacheing[x][SetN].LRU == true) {

					TwoWayCacheing[x][SetN].Tag = Tag;
					TwoWayCacheing[x][SetN].invaild = false;
					TwoWayCacheing[x][SetN].LRU = false;
					TwoWayCacheing[!x][SetN].Tag = true;
					break;
					
				}

			}

		}
		




		
		std::cout << "\n======================================================================== " << std::endl;
		std::cout << "The line number of the data loaded from memory is    " << SetN << std::endl;
		std::cout << "SetN   => " << SetN << std::endl;
		std::cout << "\nStatus of hits and Miss:" << std::endl;
		std::cout << "Amount of hits   => " << std::dec << HIT << std::endl;
		std::cout << "Amount of misses => " << std::dec << MISS << std::endl;

}







void SetAssociate(unsigned int CPUaddress)
{
	
	std::cout << "\n+++++++++++++++++++++++++++++++++++++Address has been read in :: " << hex << CPUaddress << std::endl;

	//isolating the tag, wrd field by preforming a bitwise AND '&' operation
	unsigned int BytesN = CPUaddress & WordHex;             //bitwise AND the WordHex with cpu address, save to BytesN with size 32 bits
	unsigned int Tag = CPUaddress & FULL_Assoctiv_TagHex;   //bitwise AND the TagHex  with cpu address, save to Tag   with size 32 bits

	/*
	FULL_Assoctiv_TagHex defind at top as "#define FULL_Assoctiv_TagHex 0xFFFFFFFC;" //11111111111111111111111111111100
	we have added the old tag (16-bits) + set (14-bits) fields to create the new tag field for fully associative
	FULL_Assoctiv_TagHex field is now 30 bits  
	*/

	//right shift the tag
	Tag = Tag >> 2;


	std::cout << "\nThe resulting address in the form:" << std::endl;
	std::cout << "BytesN => " << BytesN << std::endl; 
	std::cout << "TAG => "    << Tag    << std::endl; 

	std::cout << "\n=================================================HIT=========MISS======= " << std::endl;

	int flag = 0;// will be 0 if there was no avalible sapce in cache to store address, ie cache is full  
	int flagHM = 0;//  hit miss flag, 1 = hit, 0 = miss

	

	//checking for any hit in cache, if there is a hit set the flagHM flag to 1 and break from loop
	for (int x = 0; x < index_size; x++) {

		if ((FullyAssociativeMap[x].Tag == Tag) && (FullyAssociativeMap[x].invaild == false)){
			std::cout << "\nAddress is                                      a Hit  " << std::endl;
			flagHM = 1;
			break;

		}
		else{
			flagHM = 0;
		}
	}


	//using flagHM to increment the hit/ miss counter
	if (flagHM == 1)
	{
		HIT++;

	}
	else if (flagHM == 0)
	{

		MISS++;

		//finding the first invalid space in cache and save address there 
		for (int x = 0; x < index_size; x++){

			if (FullyAssociativeMap[x].invaild == true){
				//using another flag called "flag", will be 0 if this "if" condtion never ran meaning address was never saved 
				//if its 0 then the next if statment will not run 
				flag = 1;
				std::cout << "\nAddress is                                                   a Miss  " << std::endl;
				FullyAssociativeMap[x].Tag = Tag;
				FullyAssociativeMap[x].invaild = false;
				break;//exit loop once address saved
			}
		}

		//if "flag" == 0, means it was never saved in cache, therefore we execute FIFO policy
		if (flag == 0)
		{
			
			//move all cache lines by one
			//therefore the last index will be removed 
			for (int x = 0; x < index_size; x++)//move all cache down
			{

				//move all down one
				FullyAssociativeMap[x+1] = FullyAssociativeMap[x ];

			}

			//once cache lines are moved down 
			//save the address to the top, ie index 0 
			FullyAssociativeMap[0].Tag = Tag;
			FullyAssociativeMap[0].invaild = false;

		}
	}

	std::cout << "\n======================================================================== " << std::endl;
	std::cout << "\nAmount of hits => " << std::dec << HIT << std::endl;
	std::cout << "Amount of misses => " << std::dec << MISS << std::endl;


}
	





void initilise_all_cache() {

	//initilise the cache for directmap & FullyAssociativeMap together as they are 1-D array 
	//could have only set the invalid to true, and left out the other fields. 
	//but for clarity all fields were initialised    
	for (int i = 0; i < index_size; i++){
		directmap[i].invaild = true;
		directmap[i].LRU = true;
		directmap[i].Tag = true;

		FullyAssociativeMap[i].invaild = true;
		FullyAssociativeMap[i].LRU = true;
		FullyAssociativeMap[i].Tag = true;

	}

	//TwoWayCacheing declared as a 2-d array so use 2 'for' loops to initilise the fields
	for (int x = 0; x < 2; x++) {
		for (int i = 0; i < index_size; i++) {
			TwoWayCacheing[x][i].invaild = true;
			TwoWayCacheing[x][i].LRU = true;
			TwoWayCacheing[x][i].Tag = true;
		}
	}

}



int user_cache_pick(int a) {

	my_file.open(fileName, ios::in);
	if (!my_file){
		std::cout << "Error in reading file: " << std::endl;
		return 0;//this will not make code for total hits and misses run
	}



	if (a == 1){
		while (my_file >> hex >> CPUaddr) //converting hex to decimal int cpuaddr
		{
			DirectMap(CPUaddr);
		}
		my_file.close();//close file after completion 
	}
	else if (a == 2){
		while (my_file >> hex >> CPUaddr) //converting hex to decimal int cpuaddr
		{
			Twowayset(CPUaddr);
		}
		my_file.close();

	}
	else if (a == 3){
		while (my_file >> hex >> CPUaddr) //converting hex to decimal int cpuaddr
		{
			SetAssociate(CPUaddr);
		}
		my_file.close();
	}
	else { 
		std::cout << "!!Error you did not select any number between 1-3 " << std::endl; 
		return 0; //this will not make code for total hits and misses run
	}

	return 1;//this will make code for total hits and misses run 
}